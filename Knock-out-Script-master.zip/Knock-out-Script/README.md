# Knock-out-Script

# I share files for pleasure so feel free to use or modify them.

Knockout script for Fivem GTA V servers
inspired from https://forum.cfx.re/u/Cosmo


# About Script :

Stand alone script that let you knockout player when you enter melee combat, player gets knocked out after three punches and remain at ground for 15 seconds
* Player get knocked with weapon_unarmed only
* Cam effect when player gets knocked out
* Cam effect when player is knocked out
* After KO, the player can still die
* After 15 seconds all camera effects are gone and the player stands up

# Requirements :

None

# Installation :

* Rename script to Knockout
* Add it to your resource folder
* And add to your server.cfg

start Knockout 

## If you get any errors or issues, please create an [Issue](https://github.com/zharrane/Knock-out-Script/issues/new).

[When you get knocked](https://youtu.be/rgFmN-q2Eas)
[When knock someone](https://youtu.be/LgmAvoq3EI0)

## PS: i removed the progress bar you can implement any

### Feel free to use this script share it or modify it.
